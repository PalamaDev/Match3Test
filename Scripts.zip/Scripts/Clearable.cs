﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Match3Core{
	public class Clearable : MonoBehaviour {

		private AnimationClip clearAnim;

		private bool isBeingCleared = false;

		public bool IsBeingCleared{
			get{ return isBeingCleared;}
		}

		public void SetAnimationOnClear(AnimationClip clearAnim)
		{
			this.clearAnim = clearAnim;
		}

		public void Clear()
		{
			isBeingCleared = true;
			StartCoroutine (ClearCoroutine ());
		}

		public virtual IEnumerator ClearCoroutine()
		{
			Animator animator = GetComponent<Animator> ();
			if (animator) {
				animator.Play (clearAnim.name);
				yield return new WaitForSeconds (clearAnim.length);
				Destroy (gameObject);
			}
		}

	}
}

