﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

namespace Match3Core{
public class ConfigInput : MonoBehaviour {
	
	internal List<ColorsConfig> config = new List<ColorsConfig> ();

	public virtual void CreateConfig8v8()
	{
		config.Add(new ColorsConfig(new List<int>(){0,1,2,3,4,5,0,2}));
		config.Add(new ColorsConfig(new List<int>(){2,3,0,1,2,3,0,1}));
		config.Add(new ColorsConfig(new List<int>(){0,1,2,3,4,5,0,2}));
		config.Add(new ColorsConfig(new List<int>(){2,3,0,1,2,3,0,1}));
		config.Add(new ColorsConfig(new List<int>(){0,1,2,3,4,5,0,2}));
		config.Add(new ColorsConfig(new List<int>(){2,3,0,1,2,3,0,1}));
		config.Add(new ColorsConfig(new List<int>(){0,1,2,3,4,5,0,2}));
		config.Add(new ColorsConfig(new List<int>(){2,3,0,1,2,3,0,1}));
	}

	public void SaveInFileJson(string path)
	{
		CreateConfig8v8 ();
		TextWriter tw = new StreamWriter(path);
		tw.Write (JsonHelper.ToJson (config,true));
		tw.Close();
	}

	public void ReadJsonFromFile(string path)
	{
		string json = File.ReadAllText(path);
		config = JsonHelper.FromJson<ColorsConfig> (json);
	}
}

[System.Serializable]
public class ColorsConfig
{
	public	List<int> idColor;

	public ColorsConfig(List<int>idColor)
	{
		this.idColor = idColor;
	}
}

public static class JsonHelper
{
	public static List<T> FromJson<T>(string json)
	{
		Wrapper<T> wrapper = JsonUtility.FromJson<Wrapper<T>>(json);
		return wrapper.Items;
	}

	public static string ToJson<T>(List<T> list)
	{
		Wrapper<T> wrapper = new Wrapper<T>();
		wrapper.Items = list;
		return JsonUtility.ToJson(wrapper);
	}

	public static string ToJson<T>(List<T> list, bool prettyPrint)
	{
		Wrapper<T> wrapper = new Wrapper<T>();
		wrapper.Items = list;
		return JsonUtility.ToJson(wrapper, prettyPrint);
	}

	[System.Serializable]
	private class Wrapper<T>
	{
		public List<T> Items;
	}
}
}
