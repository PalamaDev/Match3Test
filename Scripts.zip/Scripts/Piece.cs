﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Match3Core{
public class Piece : MonoBehaviour {

	private int x;
	private int y;

	public int X
	{
		get{ return x;}	
		set{
			if (IsMovable ()) {
				x = value;
				gameObject.name = "Piece("+x+":"+y+")";

			}
		}
	}

	public int Y
	{
		get{ return y;}
		set{
			if (IsMovable ()) {
				y = value;
				gameObject.name = "Piece("+x+":"+y+")";
			}
		}
	}

	private PieceType type;

	public PieceType Type
	{
		get{ return type;}
	}

	private Grid grid;

	public Grid GridRef
	{
		get{return grid;}
	}

	private Mover moverComponent;

	public Mover MoverComponent
	{
		get { return moverComponent;}
	}

	private PieceColor pieceColorComponent;

	public PieceColor PieceColorComponent
	{
		get { return pieceColorComponent;}
	}

	private Clearable clearableComponent;

	public Clearable ClearableComponent
	{
		get{ return clearableComponent;}
	}

	private void Awake()
	{
		moverComponent = GetComponent<Mover> ();
		pieceColorComponent = GetComponent<PieceColor> ();
		clearableComponent = GetComponent<Clearable> ();
	}

	public void Init(int _x, int _y, Grid _grid, PieceType _type)
	{
		x = _x;
		y = _y;
		grid = _grid;
		type = _type;
	}

	private void OnMouseEnter()
	{
		grid.EnterPiece (this);
	}

	private void OnMouseDown()
	{
		grid.PressPiece (this);
	}

	private void OnMouseUp()
	{
		grid.ReleasePice ();
	}

	public bool IsMovable()
	{
		return moverComponent != null;
	}

	public bool IsHaveColor()
	{
		return pieceColorComponent != null;
	}

	public bool IsClearable()
	{
		return clearableComponent != null;
	}
}
}
