﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour {
	public int targetScore;
	public float targetTime;
	public float TargetTime{
		get { return targetTime;}
		set { targetTime = value;
			hudComponent.SetTime (targetTime);
			CheckOver ();}
	}
	private int startScore;
	private int score;
	public int Score{
		get{ return score;}
		set{ score = value;
			hudComponent.SetScore (score, targetScore);
			CheckOver ();}
	}
	private bool isOver = false;

	public HUDController hudComponent;

	private void Start () {
		hudComponent.SetScore (score, targetScore);
	}

	private void Update () {
		if (!isOver)
			TargetTime -= Time.deltaTime;
	}

	public void AddScore()
	{
		Score++;
	}

	private void CheckOver()
	{
		if (Score >= targetScore) {
			isOver = true;
			score = targetScore-1;
			hudComponent.ShowWin ();
			Time.timeScale = 0;
		}
		if (TargetTime < 0) {
			isOver = true;
			hudComponent.ShowGameOver ();
			Time.timeScale = 0;

		}
	}
}
