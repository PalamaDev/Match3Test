﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class HUDController : MonoBehaviour {

	public Text scoreCounter;
	public Text timerCounter;
	public Text panelName;
	public GameObject OverWinPanel;


	public virtual void SetScore(int curScore, int targetScore )
	{
		scoreCounter.text = curScore + "/" + targetScore;
	}

	public virtual void SetTime(float time)
	{
		string minutes = Mathf.Floor(time / 60).ToString("00");
		string seconds = (time % 60).ToString("00");
		if (time>0)
			timerCounter.text = minutes + ":" + seconds;
		else
			timerCounter.text =  "00:00";
	}
		
	internal void ShowGameOver()
	{
		panelName.text = "Game Over";
		OverWinPanel.SetActive (true);
	}

	internal void ShowWin()
	{
		panelName.text = "Complete";
		OverWinPanel.SetActive (true);
	}

	public void Restart()
	{
		Time.timeScale = 1;
		SceneManager.LoadScene ("Game");
	}

	public void GoHome()
	{
		Time.timeScale = 1;
		SceneManager.LoadScene ("MainMenu");
	}
		
}
