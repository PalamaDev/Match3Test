﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Match3Core{
	public enum PieceType{ 
		EMPTY,
		NORMAL
	}
	[System.Serializable]
	public struct PiecePrefab
	{
		public PieceType type;
		public GameObject prefab;
	}

public class Grid : MonoBehaviour {

	private int xDim;
	private int yDim;
	private float fillTime;
	private Level levelComponent;

	private bool isLoadFromConfig;

	private string path;

	private PiecePrefab[] piecePrefabs;
	private GameObject backroundPrefab;

	private Piece pressPiece;
	private Piece nextPiece;

	private Dictionary<PieceType, GameObject> piecePrefabDict;
	private Piece[,] pieces;
	private ConfigInput configInput = new ConfigInput();
	private bool isFillEndFromFile;
	private int counterFill = 0;

	public void SetProperty(float filTIme, Level leveComponent, bool isLoadFromFile, string path)
	{
		this.fillTime = filTIme;
		this.levelComponent = leveComponent;
		this.isLoadFromConfig = isLoadFromFile;
		this.path = path;
	}

	public void SetObject(PiecePrefab[] piecePrefabs, GameObject backroundPrefab)
	{
		this.piecePrefabs = piecePrefabs;
		this.backroundPrefab = backroundPrefab;
	}

	public void GenerateGrid (int x, int y) {
			xDim = x;
			yDim = y;

		CameraResize ();
		if (isLoadFromConfig)
			configInput.ReadJsonFromFile (path);

		piecePrefabDict = new Dictionary<PieceType, GameObject> ();
		for (int i = 0; i < piecePrefabs.Length; i++) {
			if (!piecePrefabDict.ContainsKey (piecePrefabs [i].type)) {
				piecePrefabDict.Add (piecePrefabs [i].type, piecePrefabs [i].prefab);
			}
		}

		for (int i = 0; i < xDim; i++) {
			for (int j = 0; j < yDim; j++) {
				GameObject background = Instantiate(backroundPrefab,GetWorldPos(i,j),Quaternion.identity);
				background.transform.SetParent(transform);
			}
		}

		pieces = new Piece[xDim, yDim];
		for (int i = 0; i < xDim; i++) {
			for (int j = 0; j < yDim; j++) {
				SpawnNewPiece (i, j, PieceType.EMPTY);
			}
		}
		StartCoroutine(Fill ());

	}
			
	private void CameraResize()
	{
		if (yDim>=10)
			Camera.main.orthographicSize = yDim / 2 + 1;
	}
		
	private IEnumerator Fill()
	{
		bool needsRefrash = true;
		while (needsRefrash) {
			yield return new WaitForSeconds (fillTime);
			while (FillStep ()) {
				yield return new WaitForSeconds (fillTime);
				counterFill++;
			}
			needsRefrash = ClearAllValidMatches ();
		}
	}

	private bool FillStep()
	{
		bool movedPiece = false;
		for (int j = yDim-2; j >= 0; j--) {
			for (int i = 0; i < xDim; i++) {
				Piece piece = pieces [i, j];
				if (piece.IsMovable ()) {
					Piece pieceBellow = pieces [i, j + 1];
					if (pieceBellow.Type == PieceType.EMPTY) {
						Destroy (pieceBellow.gameObject);

						piece.MoverComponent.Move (i, j + 1, fillTime);
						pieces [i, j + 1] = piece;
						SpawnNewPiece (i, j, PieceType.EMPTY);
						movedPiece = true;
					}
				}
			}
		}
		for (int i = 0; i < xDim; i++) {
			Piece pieceBellow = pieces [i, 0];
			if (pieceBellow.Type == PieceType.EMPTY) {
				Destroy (pieceBellow.gameObject);

				GameObject newPiece = Instantiate (piecePrefabDict [PieceType.NORMAL], GetWorldPos (i, -1), Quaternion.identity);
				newPiece.transform.SetParent (transform);


				pieces [i, 0] = newPiece.GetComponent<Piece> ();
				pieces [i, 0].Init (i, -1, this, PieceType.NORMAL);
				pieces [i, 0].MoverComponent.Move (i, 0, fillTime);

				if (!isLoadFromConfig) {
					pieces [i, 0].PieceColorComponent.SetColor ((PieceColor.Colors)Random.Range (0, pieces [i, 0].PieceColorComponent.NumColors));
				} else {
					if (isFillEndFromFile)
						pieces [i, 0].PieceColorComponent.SetColor ((PieceColor.Colors)Random.Range (0, pieces [i, 0].PieceColorComponent.NumColors));
					else {
						if (counterFill != yDim) {
							pieces [i, 0].PieceColorComponent.SetColor ((PieceColor.Colors)configInput.config [counterFill].idColor [i]);
						} else {
							counterFill = 0;
							isFillEndFromFile = true;
						}
					}
				}
				movedPiece = true;
			}

		}

		return movedPiece;
	}

	public Vector2 GetWorldPos(float x, float y)
	{
		return new Vector2 (transform.position.x - xDim / 2 + x,
				transform.position.y + yDim / 2 - y);
	}

	private Piece SpawnNewPiece(int x, int y, PieceType type)
	{
		GameObject newPiece = Instantiate (piecePrefabDict [type], GetWorldPos (x, y), Quaternion.identity);
		newPiece.transform.SetParent (transform);


		pieces [x, y] = newPiece.GetComponent<Piece> ();
		pieces [x, y].Init (x, y, this, type);

		return pieces [x, y];
	}

	private bool isAjacent(Piece piece1, Piece piece2)
	{
		return (piece1.X == piece2.X && (int)Mathf.Abs (piece1.Y - piece2.Y) == 1)
			|| (piece1.Y == piece2.Y && (int)Mathf.Abs (piece1.X - piece2.X) == 1);
	}

	private void SwapPiecess(Piece piece1, Piece piece2)
	{
		if (piece1.IsMovable () && piece2.IsMovable ()) {
			pieces [piece1.X, piece1.Y] = piece2;
			pieces [piece2.X, piece2.Y] = piece1;

			if (GetMatch (piece1, piece2.X, piece2.Y) != null || GetMatch (piece2, piece1.X, piece1.Y) != null) {

				int piece1X = piece1.X;
				int piece1Y = piece1.Y;

				piece1.MoverComponent.Move (piece2.X, piece2.Y, fillTime);
				piece2.MoverComponent.Move (piece1X, piece1Y, fillTime);

				pressPiece = null;
				nextPiece = null;

				ClearAllValidMatches ();

				StartCoroutine (Fill ());
			} else {
				pieces [piece1.X, piece1.Y] = piece1;
				pieces [piece2.X, piece2.Y] = piece2;
			}
		}
	}

	public void PressPiece(Piece piece)
	{
		pressPiece = piece;
	
	}

	public void EnterPiece(Piece piece)
	{
		nextPiece = piece;
	}

	public void ReleasePice()
	{
		if (isAjacent (pressPiece, nextPiece)) {
			SwapPiecess (pressPiece, nextPiece);
		} 
	}

	private List<Piece> GetMatch(Piece piece, int newX, int newY)
	{
		if (piece.IsHaveColor ()) {
			PieceColor.Colors color = piece.PieceColorComponent.Color;
			List<Piece> horizontalPieces = new List<Piece> ();
			List<Piece> verticalPieces = new List<Piece> ();
			List<Piece> matchingPieces = new List<Piece> ();
			
			FindGorizontalMatch(piece,newX,newY,horizontalPieces,color);
			FindVerticalMatch (piece, newX, newY, verticalPieces, color);

			if (horizontalPieces.Count >= 3) {
				for (int i = 0; i < horizontalPieces.Count; i++) {
					matchingPieces.Add (horizontalPieces [i]);
				}
			}
			if (verticalPieces.Count >= 3) {
				for (int i = 0; i < verticalPieces.Count; i++) {
					matchingPieces.Add (verticalPieces [i]);
				}
			}
			if (matchingPieces.Count >= 3) {
				return matchingPieces;
			}
		}
		return null;
	}

	public virtual void FindGorizontalMatch(Piece piece, int newX, int newY, List<Piece> horizontalPieces,PieceColor.Colors color)
	{
		horizontalPieces.Add(piece);

		for (int dir = 0; dir <= 1; dir++) {
			for (int xOffset = 1; xOffset < xDim; xOffset++) {
				int x;

				if (dir == 0) { // Left
					x = newX - xOffset;
				} else { // Right
					x = newX + xOffset;
				}

				if (x < 0 || x >= xDim) {
					break;
				}

				if (pieces [x, newY].IsHaveColor () && pieces [x, newY].PieceColorComponent.Color == color) {
					horizontalPieces.Add (pieces [x, newY]);
				} else {
					break;
				}
			}
		}
		if (horizontalPieces.Count == 4) {
			for (int i = 0; i < ClearRow(horizontalPieces[0].Y).Count; i++) {
				horizontalPieces.Add (ClearRow(horizontalPieces[0].Y)[i]);
			}	
		}

		if (horizontalPieces.Count == 5) {
			for (int i = 0; i < ClearAllColorSelected (horizontalPieces[0].PieceColorComponent.Color).Count; i++) {
				horizontalPieces.Add (ClearAllColorSelected (horizontalPieces[0].PieceColorComponent.Color)[i]);
			}
		}
	}
	public virtual void FindVerticalMatch(Piece piece, int newX, int newY, List<Piece> verticalPieces,PieceColor.Colors color)
	{
		verticalPieces.Add(piece);

		for (int dir = 0; dir <= 1; dir++) {
			for (int yOffset = 1; yOffset < yDim; yOffset++) {
				int y;

				if (dir == 0) { // Up
					y = newY - yOffset;
				} else { // Down
					y = newY + yOffset;
				}

				if (y < 0 || y >= yDim) {
					break;
				}

				if (pieces [newX, y].IsHaveColor () && pieces [newX, y].PieceColorComponent.Color == color) {
					verticalPieces.Add (pieces [newX, y]);
				} else {
					break;
				}
			}
		}

		if (verticalPieces.Count == 4) {
			for (int i = 0; i < ClearColumn(verticalPieces[0].X).Count; i++) {
				verticalPieces.Add (ClearColumn(verticalPieces[0].X)[i]);
			}
		}

		if (verticalPieces.Count == 5) {
			for (int i = 0; i < ClearAllColorSelected (verticalPieces[0].PieceColorComponent.Color).Count; i++) {
				verticalPieces.Add (ClearAllColorSelected (verticalPieces[0].PieceColorComponent.Color)[i]);
			}
		}
	}

	private bool ClearAllValidMatches()
	{
		bool needsRefill = false;
		for (int y = 0; y < yDim; y++) {
			for (int x = 0; x < xDim; x++) {
				if (pieces [x, y].IsClearable ()) {
					List<Piece> match = GetMatch (pieces [x, y], x, y);
					if (match != null) {
						for (int i = 0; i < match.Count; i++) {

							levelComponent.AddScore ();

							if (ClearPiece (match [i].X, match [i].Y)) {
								needsRefill = true;
							}
						}
					}
				}
			}
		}
		return needsRefill;
	}

	private bool ClearPiece(int x, int y)
	{
		if (pieces [x, y].IsClearable () && !pieces [x, y].ClearableComponent.IsBeingCleared) {
			pieces [x, y].ClearableComponent.Clear ();
			SpawnNewPiece (x, y, PieceType.EMPTY);

			return true;
		}
		return false;
	}

	private List<Piece> ClearRow(int row)
	{
		List<Piece> pieceRow = new List<Piece> ();
		for (int x = 0; x < xDim; x++) {
			if (pieces [x, row].IsClearable ()) {
				pieceRow.Add (pieces [x, row]);
			}
		}
		return pieceRow;
	}

	private List<Piece> ClearColumn(int column)
	{
		List<Piece> pieceColumn = new List<Piece> ();
		for (int y = 0; y < yDim; y++) {
			if (pieces [column, y].IsClearable ()) {
				pieceColumn.Add(pieces[column,y]);
			}
		}
		return pieceColumn;
	}

	private List<Piece> ClearAllColorSelected(PieceColor.Colors color)
	{
		List<Piece> pieceColor = new List<Piece> ();
		for (int x = 0; x < xDim; x++) {
			for (int y = 0; y < yDim; y++) {
				if (pieces [x, y].IsHaveColor () && (pieces [x, y].PieceColorComponent.Color == color) && !pieces [x, y].ClearableComponent.IsBeingCleared) {
					pieceColor.Add (pieces [x, y]);
				}
			}
		}
		return pieceColor;
	}
}
}
