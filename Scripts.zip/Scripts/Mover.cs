﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Match3Core{
public class Mover : MonoBehaviour {

	private Piece piece;
	private IEnumerator moveCoroutine;

	private void Awake()
	{
		piece = GetComponent<Piece> ();
	}

	public void Move(int newX,int newY, float time)
	{
		if (moveCoroutine != null) {
			StopCoroutine (moveCoroutine);
		}

		moveCoroutine = MoveCoroutine (newX, newY, time);
		StartCoroutine (moveCoroutine);
	}

	private IEnumerator MoveCoroutine(int nextX, int nextY, float time)
	{
		piece.X = nextX;
		piece.Y = nextY;

		Vector3 startPos = transform.position;
		Vector3 endPos = piece.GridRef.GetWorldPos (nextX, nextY);

		for (float t = 0; t < 1*time; t+=Time.deltaTime) {
			piece.transform.position = Vector3.Lerp (startPos, endPos, t / time);
			yield return new WaitForEndOfFrame();
		}

		transform.position = endPos;
	}

}
}