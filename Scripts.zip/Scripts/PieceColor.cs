﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Match3Core{
public class PieceColor : MonoBehaviour {

	public enum Colors
	{
		YELLOW,
		GREEN,
		ORANGE,
		PINK,
		WHITE,
		PURPLE
	};

	[System.Serializable]
	public struct SpriteColor
	{
		public Colors color;
		public Sprite sprite;

	};

	public SpriteColor[] spriteColors;

	private Colors color;

	public Colors Color
	{
		get{ return color;}
		set{ SetColor (value);}
	}

	public int NumColors{
		get{ return spriteColors.Length;}
	}

	private Dictionary<Colors, Sprite> spriteColorDict;
	private SpriteRenderer sprite;
	private void Awake()
	{
		sprite = GetComponent<SpriteRenderer> ();
		spriteColorDict = new Dictionary<Colors, Sprite> ();

		for (int i = 0; i < spriteColors.Length; i++) {
			if (!spriteColorDict.ContainsKey (spriteColors [i].color)) {
				spriteColorDict.Add (spriteColors [i].color, spriteColors [i].sprite);
			}
		}
	}
	public void SetColor(Colors newColor)
	{
		color = newColor;
		if (spriteColorDict.ContainsKey (newColor)) {
			sprite.sprite = spriteColorDict [newColor];
		}
	}
}
}
